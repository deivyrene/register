<?php

namespace Siac;

use Illuminate\Database\Eloquent\Model;

class Edifice extends Model
{
    protected $fillable = [
        'nameEdifice', 'addressEdifice', 'contactEdifice', 'emailEdifice'
    ];

    public function places(){

        $this->hasMany('App\Place');
    }
    public function users(){

        $this->belongsToMany('App\User');
    }
}

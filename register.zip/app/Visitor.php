<?php

namespace Siac;

use Illuminate\Database\Eloquent\Model;

class Visitor extends Model
{
    protected $fillable = [
        'nameVisitor', 'surnameVisitor', 'rutVisitor', 'emailVisitor', 'addressVisitor'
    ];

    public function places(){
    
        return $this->belongsToMany('App\Place');
    }
}

<?php

namespace Siac;

use Illuminate\Database\Eloquent\Model;

class Place extends Model
{
    protected $fillable = [
        'numberPlace', 'namePlace', 'phonePlace', 'ownerPlace', 'edifice_id'
    ];

    public function visitors()
    {
        $this->belongsToMany('App\Visitor');
    }
}

<?php

return array(
	"name" => "No Record Found",
	"method" => "Create New");
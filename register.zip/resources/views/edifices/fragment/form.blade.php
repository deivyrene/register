<div class="form-group">
    {{ Form::label('nameEdifice', 'Nombre edificio') }}
    {{ Form::text('nameEdifice', null, ['class' => 'form-control']) }}
</div>

<div class="form-group">
        {{ Form::label('contactEdifice', 'Contacto edificio') }}
        {{ Form::text('contactEdifice', null, ['class' => 'form-control']) }}
</div>

<div class="form-group">
        {{ Form::label('addressEdifice', 'Dirección edificio') }}
        {{ Form::text('addressEdifice', null, ['class' => 'form-control']) }}
</div>
<div class="form-group">
        {{ Form::label('emailEdifice', 'Email edificio') }}
        {{ Form::text('emailEdifice', null, ['class' => 'form-control']) }}
</div>

<div class="form-group">
         {{ Form::submit('ENVIAR', ['class' => 'btn btn-warning']) }}
</div>
    <footer class="footer ">
        <div class="container-fluid">
            <nav class="pull-right">
                <ul>
                    <li>
                        <a href="http://www.sipcom.cl">
                            Acerca de SIPCOM
                        </a>
                    </li>
                </ul>
            </nav>
           <!-- <div class="copyright pull-right">
                &copy;
                <script>
                    document.write(new Date().getFullYear())
                </script>, made with
                <a href="https://www.sipcom.cl" target="_blank">SIPCOM LTDA</a> for a better web.
            </div>-->
        </div>
    </footer>
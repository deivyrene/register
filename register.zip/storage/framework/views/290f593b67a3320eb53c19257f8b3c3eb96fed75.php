<div class="form-group">
    <?php echo e(Form::label('nameEdifice', 'Nombre edificio')); ?>

    <?php echo e(Form::text('nameEdifice', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('contactEdifice', 'Contacto edificio')); ?>

        <?php echo e(Form::text('contactEdifice', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('addressEdifice', 'Dirección edificio')); ?>

        <?php echo e(Form::text('addressEdifice', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
        <?php echo e(Form::label('emailEdifice', 'Email edificio')); ?>

        <?php echo e(Form::text('emailEdifice', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
         <?php echo e(Form::submit('ENVIAR', ['class' => 'btn btn-warning'])); ?>

</div>
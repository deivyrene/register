<div class="form-group">
    <?php echo e(Form::label('nameCompany', 'Nombre empresa')); ?>

    <?php echo e(Form::text('nameCompany', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('attendantCompany', 'Encargado empresa')); ?>

        <?php echo e(Form::text('attendantCompany', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('addressCompany', 'Dirección empresa')); ?>

        <?php echo e(Form::text('addressCompany', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
        <?php echo e(Form::label('fonoCompanyA', 'Fono empresa A')); ?>

        <?php echo e(Form::text('fonoCompanyA', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
        <?php echo e(Form::label('fonoCompanyB', 'Fono empresa B')); ?>

        <?php echo e(Form::text('fonoCompanyB', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
        <?php echo e(Form::label('fonoCompanyC', 'Fono empresa C')); ?>

        <?php echo e(Form::text('fonoCompanyC', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('emailCompany', 'Email empresa')); ?>

        <?php echo e(Form::text('emailCompany', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
         <?php echo e(Form::submit('ENVIAR', ['class' => 'btn btn-warning'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('nameConsultant', 'Nombre Consultor')); ?>

    <?php echo e(Form::text('nameConsultant', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('positionConsultant', 'Cargo Consultor')); ?>

        <?php echo e(Form::text('positionConsultant', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('fonoConsultant', 'Fono Consultor')); ?>

        <?php echo e(Form::text('fonoConsultant', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('emailConsultant', 'Email Consultor')); ?>

        <?php echo e(Form::text('emailConsultant', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
         <?php echo e(Form::submit('ENVIAR', ['class' => 'btn btn-warning'])); ?>

</div>
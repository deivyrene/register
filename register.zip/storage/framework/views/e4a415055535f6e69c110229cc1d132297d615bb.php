<?php $__env->startSection('content'); ?>
   <div class="col-md-12">
       
        <?php echo $__env->make('businessusers.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="card">
                <div class="card-header card-header-primary" style="background:#383131">
                    <h4 class="card-title ">
                        Listado de Usuario-Empresa
                        <a href="<?php echo e(route('businessusers.create')); ?>" class="btn btn-danger pull-right">Nuevo</a>
                    </h4>
                    
                   <!-- <p class="card-category"> Here is a subtitle for this table</p>-->
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="text-default">
                                <tr>
                                    <th width="20px">ID</th>
                                    <th>Nombre</th>
                                    <th>Fono</th>
                                    <th>Email</th>
                                    <th>Empresa</th>
                                    <th>Acción</th>
                                </tr>
                        </thead>
                        <tbody>
                            <?php //dd($businessusers); die();?>
                            <?php $__currentLoopData = $businessusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businessuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($businessuser->id); ?></td>
                                <td><?php echo e($businessuser->nameBusinessUser); ?></td>
                                <td><?php echo e($businessuser->fonoBusinessUser); ?></td>
                                <td><?php echo e($businessuser->emailBusinessUser); ?></td>
                                <td><?php echo e($businessuser->relationCompany->nameCompany); ?></td>
                                
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('businessusers.show', $businessuser->id)); ?>" class="btn btn-success "><i class="material-icons">pageview</i></a>
                                        <a href="<?php echo e(route('businessusers.edit', $businessuser->id)); ?>" class="btn btn-info "><i class="material-icons">border_color</i></a>
                                    
                                        <form action="<?php echo e(route('businessusers.destroy', $businessuser->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="DELETE" id="">
                                            <button class="btn btn-secundary "><i class="material-icons">delete_forever</i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                      <?php echo e($businessusers->links('pagination.default')); ?> 

                    </div>
                </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
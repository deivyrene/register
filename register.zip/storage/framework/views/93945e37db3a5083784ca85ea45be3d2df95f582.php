<!DOCTYPE html>
<html lang="es">

<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Styles -->
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
        <link href="https://demos.creative-tim.com/material-dashboard/assets/css/material-dashboard.min.css?v=2.0.0" rel="stylesheet">
        
</head>

<body style="background-color: #ffffff">

        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
            <table class="table table-hover border" >
                <thead>
                    <tr>
                        <td rowspan="4" colspan="3" align="center"><img src="<?php echo e(public_path('img/sipcom.png')); ?>" alt="" width="210"></td>
                        <td rowspan="4" colspan="6" align="center"><h3>SISTEMA DE GESTIÓN</h3></td>
                        <td colspan="2">Fecha 10/01/2015</td>
                    </tr>
                    <tr>
                        <td colspan="2">Versión 001</td>
                    </tr>
                    <tr>
                        <td colspan="2">Código: FRAG</td>
                    </tr>
                    <tr>
                        <td colspan="2">Página 1 de 1</td>
                    </tr>
                    <tr>
                        <td colspan="11">Informe: Registro Actividades</td>
                    </tr>

                    <tr>
                        <td colspan="5" >Cliente: <?php echo e($registeractivities[0]->companies->nameCompany); ?></td>
                        <td colspan="6" >Contacto Cliente: <?php echo e($registeractivities[0]->companies->attendantCompany); ?></td>
                    </tr>
                    <tr>
                        <td colspan="5" >Fecha: <?php echo e($registeractivities[0]->dateRegisterActivities); ?></td>
                        <td colspan="6" >Mail Contacto: <?php echo e($registeractivities[0]->companies->emailCompany); ?></td>
                    </tr>
                    <tr>
                        <td colspan="11" >Consultor: <?php echo e($registeractivities[0]->consultants->nameConsultant); ?></td>
                    </tr>
                    
                    <tr>
                        <td colspan="11"></td>
                    </tr>

                </thead>
                <tbody>
                    <tr class="text-white bg-dark">
                        <td colspan="3">Usuarios que aplica</td>
                        <td colspan="3">Tipo Actividad</td>
                        <td colspan="3">Descripción Actividad</td>
                        <td colspan="2">Fecha</td>
                    </tr>
                    <?php $__currentLoopData = $registeractivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registeractivity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3"><?php echo e($registeractivity->businessuser->nameBusinessUser); ?></td>
                        <td colspan="3"><?php echo e($registeractivity->activities->nameActivity); ?></td>
                        <td colspan="3"><?php echo e($registeractivity->desRegisterActivity); ?></td>
                        <td colspan="2"><?php echo e($registeractivity->dateRegisterActivity); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
            <div class="col-md-1"></div>
        </div>

</body>

</html>
<div class="form-group">
    <?php echo e(Form::label('nameActivity', 'Nombre Actividad')); ?>

    <?php echo e(Form::text('nameActivity', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('shortActivity', 'Descripcion Actividad')); ?>

        <?php echo e(Form::text('shortActivity', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
         <?php echo e(Form::submit('ENVIAR', ['class' => 'btn btn-warning'])); ?>

</div>
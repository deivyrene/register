<?php if(Session::has('info')): ?>
    <div class="alert alert-success">
        <button class="close" data-dismiss="alert">
            &times;
        </button>
        <?php echo e(Session::get('info')); ?>

    </div>
<?php endif; ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="col-md-12">
            <div class="card-header card-header-primary" style="background:#383131">
                <h2>
                    Nuevo Registro de Actividad
                    <a href="<?php echo e(route('registeractivities.index')); ?>" class="btn btn-info pull-right">Volver</a>
                </h2>
            </div>
            <div class="card-body">
                <?php echo $__env->make('registeractivities.fragment.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo e(Form::open(['route' => 'registeractivities.store'])); ?>


                    <?php echo $__env->make('registeractivities.fragment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
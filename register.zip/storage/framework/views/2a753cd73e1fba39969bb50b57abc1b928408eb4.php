<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="col-md-12">
            <div class="card-header card-header-primary" style="background:#383131">
                <h2>
                    Detalle de Actividades
                    <a title="Listar Actividades" href="<?php echo e(route('registeractivities.index')); ?>" class="btn btn-info pull-right"><i class="material-icons">list</i></a>
                    <!--<a title="Generar PDF" href="#" onclick="pdf()" class="btn btn-danger pull-right"><i class="material-icons">picture_as_pdf</i></a>-->
                    <a title="Generar PDF" href="<?php echo e(url('pdf', $registeractivities[0]->codActivity)); ?>" class="btn btn-danger pull-right"><i class="material-icons">picture_as_pdf</i></a>
                    <a title="Enviar Correo" href="<?php echo e(url('sendmail', $registeractivities[0]->codActivity)); ?>" class="btn btn-info pull-right"><i class="material-icons">email</i></a>
                </h2>
            </div>

    <div class="card-body">
        <div id="documento">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                <table class="table table-hover border" >
                    <thead>
                        <tr>
                            <td rowspan="4" colspan="3" align="center"><img src="<?php echo e(asset('img/sipcom.png')); ?>" alt=""></td>
                            <td rowspan="4" colspan="6" align="center"><h3>SISTEMA DE GESTIÓN</h3></td>
                            <td colspan="2">Fecha 10/01/2015</td>
                        </tr>
                        <tr>
                            <td colspan="2">Versión 001</td>
                        </tr>
                        <tr>
                            <td colspan="2">Código: FRAG</td>
                        </tr>
                        <tr>
                            <td colspan="2">Página 1 de 1</td>
                        </tr>
                        <tr>
                            <td colspan="11">Informe: Registro Actividades</td>
                        </tr>

                        <tr>
                            <td colspan="5" >Cliente: <?php echo e($registeractivities[0]->companies->nameCompany); ?></td>
                            <td colspan="6" >Contacto Cliente: <?php echo e($registeractivities[0]->companies->attendantCompany); ?></td>
                        </tr>
                        <tr>
                            <td colspan="5" >Fecha: <?php echo e($registeractivities[0]->dateRegisterActivities); ?></td>
                            <td colspan="6" >Mail Contacto: <?php echo e($registeractivities[0]->companies->emailCompany); ?></td>
                        </tr>
                        <tr>
                            <td colspan="11" >Consultor: <?php echo e($registeractivities[0]->consultants->nameConsultant); ?></td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>

                    </thead>
                    <tbody>
                        <tr class="text-white bg-dark">
                            <td colspan="2">Usuarios que aplica</td>
                            <td colspan="2">Tipo Actividad</td>
                            <td colspan="2">Descripción Actividad</td>
                            <td colspan="5">Fecha</td>
                        </tr>
                        <?php $__currentLoopData = $registeractivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registeractivity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2"><?php echo e($registeractivity->businessuser->nameBusinessUser); ?></td>
                            <td colspan="2"><?php echo e($registeractivity->activities->nameActivity); ?></td>
                            <td colspan="2"><?php echo e($registeractivity->desRegisterActivity); ?></td>
                            <td colspan="5"><?php echo e($registeractivity->dateRegisterActivity); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
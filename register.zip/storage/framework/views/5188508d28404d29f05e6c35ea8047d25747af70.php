<div class="row">
        <div class="col-sm form-group">
                <?php echo e(Form::label('dateRegisterActivities', 'Fecha Registro')); ?>

                <?php echo e(Form::date('dateRegisterActivities', \Carbon\Carbon::now(), ['class' => 'form-control'])); ?>

        </div>
        <input type="hidden" name="codActivity" id="codActivity" value="<?php echo e($clave); ?>">
        
        <div class="col-sm form-group">
                <?php echo e(Form::label('consultants_id', 'Consultor')); ?>

                <select class="form-control" name="consultants_id" id="consultants_id">
                                <option value="0">Seleccione</option>
                        <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($consultant->id); ?>" ><?php echo e($consultant->nameConsultant); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>

        <div class="col-sm form-group">
                <?php echo e(Form::label('companies_id', 'Empresa')); ?>

                <select class="form-control" name="companies_id" id="companies_id">
                                <option value="0">Seleccione</option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>" ><?php echo e($company->nameCompany); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
</div>
<div class="row">
        <div class="col-sm-3 form-group">
                <?php echo e(Form::label('businessuser', 'Usuarios')); ?>

                <select class="form-control" name="businessuser_id" id="businessuser_id">
                                <option value="0">Seleccione</option>
                </select>
        </div>

        <div class="col-sm-2 form-group">
                <?php echo e(Form::label('activities_id', 'Actividad')); ?>

                <select class="form-control" name="activities_id" id="activities_id">
                                <option value="0">Seleccione</option>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($activity->id); ?>" ><?php echo e($activity->nameActivity); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
        </div>
        <div class="col-sm-3 form-group">
                <?php echo e(Form::label('desRegisterActivity', 'Estatus')); ?>

                <?php echo e(Form::text('desRegisterActivity',null, ['class' => 'form-control'])); ?>

        </div>

        <div class="col-sm-2 form-group">
                <?php echo e(Form::label('dateRegisterActivity', 'Fecha')); ?>

                <?php echo e(Form::date('dateRegisterActivity', \Carbon\Carbon::now(), ['class' => 'form-control'])); ?>               
        </div>

        <div class="col-sm-2 form-group">
                <br>
                <a href="#" id="saveActivity" class="btn btn-success pull-right"><i class="material-icons">save</i></a>
        </div>

</div>
<hr>
<div class="row card-body">
        <div class="col-sm-1"></div>
        <div class="table-responsive col-sm-10">
        <table class="table table-hover">
            <thead class="text-default">
                <tr>
                    <td>Nombre Usuario</td>
                    <td>Actividad</td>
                    <td>Estatus</td>
                    <td>Fecha</td>
                    <td>Acción</td>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        </div>
        <div class="col-sm-1"></div>
</div>

<center>
<div class="form-group">
                <a href="<?php echo e(route('registeractivities.index')); ?>" class="btn btn-info ">GUARDAR</a>
</div>
</center>
        
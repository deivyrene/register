<div class="form-group">
    <?php echo e(Form::label('nameBusinessUser', 'Nombre usuario')); ?>

    <?php echo e(Form::text('nameBusinessUser', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('fonoBusinessUser', 'Fono usuario')); ?>

        <?php echo e(Form::text('fonoBusinessUser', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('emailBusinessUser', 'Email usuario')); ?>

        <?php echo e(Form::text('emailBusinessUser', null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::label('idCompanies', 'Empresa')); ?>

        <select class="form-control" name="idCompanies" id="idCompanies">
                        <option value="0">Seleccione</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?= $company->id ?>" <?php if(isset($businessuser)){ if($businessuser->idCompanies == $company->id){ echo "selected"; } }?> ><?php echo e($company->nameCompany); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
</div>


<div class="form-group">
         <?php echo e(Form::submit('ENVIAR', ['class' => 'btn btn-warning'])); ?>

</div>
<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('name', 'Nombre Usuario')); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>


        <?php if($errors->has('name')): ?>
            <span class="help-block">
                 <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('email', 'Email')); ?>

        <?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

        
        <?php if($errors->has('email')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
        <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
        <?php echo e(Form::label('password', 'Contraseña')); ?>

        <?php echo e(Form::password('password', ['class' => 'form-control'])); ?>


        <?php if($errors->has('password')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
        <?php endif; ?>
</div>

<div class="form-group">
        <?php echo e(Form::label('password-confirm', 'Confirmar Contraseña')); ?>

        <?php echo e(Form::password('password-confirm', ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
        <?php echo e(Form::submit('ENVIAR', ['class' => 'btn btn-warning'])); ?>

</div>